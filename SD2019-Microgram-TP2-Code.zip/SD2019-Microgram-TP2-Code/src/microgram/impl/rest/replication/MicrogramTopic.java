package microgram.impl.rest.replication;

public enum MicrogramTopic {
	MicrogramEvents, PostsEvents, ProfilesEvents;
}
