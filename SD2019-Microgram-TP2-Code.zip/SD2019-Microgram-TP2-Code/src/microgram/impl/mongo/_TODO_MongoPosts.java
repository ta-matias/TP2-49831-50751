package microgram.impl.mongo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static microgram.api.java.Result.error;
import static microgram.api.java.Result.ok;
import static microgram.api.java.Result.ErrorCode.CONFLICT;
import static microgram.api.java.Result.ErrorCode.NOT_FOUND;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

import microgram.api.Post;
import microgram.api.Profile;
import microgram.api.java.Posts;
import microgram.api.java.Result;
import utils.Hash;

public class _TODO_MongoPosts implements Posts {
	
	static _TODO_MongoPosts Posts;
	
	private MongoCollection<Post> dbPostsCol;
	private MongoCollection<Profile> dbProfilesCol;
	private MongoCollection<Set<String>> dbLikesCol;
	private MongoCollection<Set<String>> dbFollowsCol;
	private MongoCollection<Set<String>> dbUserPosts;
	
	

	public _TODO_MongoPosts(MongoDatabase dbName) {
		//this.dbName -- TODO create the database????
		dbPostsCol = dbName.getCollection("dbPostsCol", Post.class);
		dbProfilesCol = dbName.getCollection("dbProfilesCol", Profile.class);
	}
	
	@Override
	public Result<Post> getPost(String postId) {
		Post post = dbPostsCol.find(Filters.eq("postId", postId)).first();
		if(post == null)
			return error(NOT_FOUND);
		
		post.setLikes((int) dbLikesCol.countDocuments(Filters.eq("userId", post.getPostId())));
		return ok(post);
	}

	@Override
	public Result<String> createPost(Post post) {
		Profile oP = dbProfilesCol.find(Filters.eq("userId", post.getOwnerId())).first(); //check if there 
		if(oP == null)
			return error(NOT_FOUND);
		
		post.setPostId(post.getOwnerId() + "-" + Hash.of(post.getMediaUrl()));
		dbPostsCol.insertOne(post);
		if(dbUserPosts.find(Filters.eq("oP.getUserId()",oP.getUserId())).first() == null)
			dbUserPosts.insertOne(new HashSet<>());
		dbUserPosts.find(Filters.eq("oP.getUserId()",oP.getUserId())).first().add(post.getPostId());
		dbLikesCol.insertOne(new HashSet<>());
		return ok(post.getPostId());
	}

	@Override
	public Result<Void> deletePost(String postId) {
		Post post = dbPostsCol.find(Filters.eq("postId", postId)).first();
		if(post == null)
			return error(NOT_FOUND);
		
		dbPostsCol.deleteOne(Filters.eq("postId", postId));
		return ok();
	}

	@Override
	public Result<Void> like(String postId, String userId, boolean isLiked) {
		//increment likes dunno how to do it here
		Set<String> likes = this.dbLikesCol.find(Filters.eq("postId", postId)).first();
		if(likes == null)
			return error(NOT_FOUND);
		if(isLiked){
			if(!likes.add(userId))
				return error(CONFLICT);
		}else{
			if(!likes.remove(userId))
				return error(NOT_FOUND);
		}
		dbLikesCol.insertOne(likes);
		return ok();
	}

	@Override
	public Result<Boolean> isLiked(String postId, String userId) {
		// TODO Auto-generated method stub
		Set<String> likes = this.dbLikesCol.find(Filters.eq("postId", postId)).first();
		if(likes != null)
			return ok(likes.contains(userId));
		else
			return error(NOT_FOUND);
	}

	@Override
	public Result<List<String>> getPosts(String userId) {
		// TODO Auto-generated method stub
		Set<String> userPosts = this.dbUserPosts.find(Filters.eq("userId", userId)).first();
		if(userPosts != null)
			return ok(new ArrayList<>(userPosts));
		return error(NOT_FOUND);
	}

	@Override
	public Result<List<String>> getFeed(String userId) {
		// TODO Auto-generated method stub
		Set<String> following = this.dbFollowsCol.find(Filters.eq("userId", userId)).first();
		if(following != null){
			List<String> feed = new ArrayList<>();
			for(String followee : following)
				feed.addAll(dbUserPosts.find(Filters.eq("followee", followee)).first());
			return ok(feed);
		}
		else
			return error(NOT_FOUND);
	}

}
