package microgram.impl.mongo;

import static microgram.api.java.Result.error;
import static microgram.api.java.Result.ok;
import static microgram.api.java.Result.ErrorCode.NOT_FOUND;

import java.util.List;
import java.util.Set;

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;

import microgram.api.Profile;
import microgram.api.java.Profiles;
import microgram.api.java.Result;

public class _TODO_MongoProfiles implements Profiles {

	static _TODO_MongoProfiles Profiles;
	
	private MongoCollection<Profile> dbProfilesCol;
	//TODO missing some data structures for following e followers
    private MongoCollection<Set<String>> dbFollowersCol;
    private MongoCollection<Set<String>> dbFollowingCol;
	
	public _TODO_MongoProfiles(MongoDatabase dbName) {
		//this.dbName -- TODO create the database????
		//dbProfilesCol = this.dbName.getCollection(DB_PROFILES_TABLE, Profiles.class);
		//do shit like that for the others
	}
	
	
	@Override
	public Result<Profile> getProfile(String userId) {
		Profile prof = dbProfilesCol.find(Filters.eq("userId", userId)).first();
		if(prof == null)
			return error(NOT_FOUND);
		
		//prof.getUserId()((int) dbProfilesCol.countDocuments(Filters.eq("userId", prof.getUserId()))));
		return ok(prof);
	}

	@Override
	public Result<Void> createProfile(Profile profile) {
		Profile prof = dbProfilesCol.find(Filters.eq("userId", profile.getUserId())).first();
		if(prof==null)
			return error(NOT_FOUND);
		
		dbProfilesCol.insertOne(profile);
		return ok();
	}

	@Override
	public Result<Void> deleteProfile(String userId) {
		Profile prof = dbProfilesCol.find(Filters.eq("userId", userId)).first();
		if(prof==null)
			return error(NOT_FOUND);
		//delete folowers when added
		//just like in java profiles
		dbProfilesCol.deleteOne(Filters.eq("userId", userId));
		//how to delete posts
		return ok();
	}

	@Override
	public Result<List<Profile>> search(String prefix) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Result<Void> follow(String userId1, String userId2, boolean isFollowing) {
		// TODO Auto-generated method stub
		Set<String> s1 = this.dbFollowingCol.find(Filters.eq("userId1", userId1)).first();
		Set<String> s2 = this.dbFollowersCol.find(Filters.eq("userId2", userId2)).first();
		
		if (s1 == null || s2 == null)
			return error(NOT_FOUND);

		if (isFollowing) {
			s1.add(userId2);
			s2.add(userId1);
		} else {
			s1.remove(userId2); 
			s2.remove(userId1);
		}
		this.dbFollowingCol.insertOne(s1);
		this.dbFollowersCol.insertOne(s2);
		return ok();
	}

	@Override
	public Result<Boolean> isFollowing(String userId1, String userId2) {
		Set<String> s1 = this.dbFollowingCol.find(Filters.eq("userId1", userId1)).first();

		if (s1 == null)
			return error(NOT_FOUND);
		else
			return ok(s1.contains(userId2));
	}
}
