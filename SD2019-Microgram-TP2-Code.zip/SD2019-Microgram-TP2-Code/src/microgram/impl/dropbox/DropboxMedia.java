package microgram.impl.dropbox;

import java.io.ByteArrayOutputStream;
import java.io.File;

import org.pac4j.oauth.client.DropBoxClient;

import com.github.scribejava.core.model.OAuth2AccessToken;
import com.github.scribejava.core.model.OAuthRequest;
import com.github.scribejava.core.model.Response;
import com.github.scribejava.core.model.Verb;
import com.github.scribejava.core.oauth.OAuth20Service;

import microgram.api.java.Media;
import microgram.api.java.Result;
import utils.JSON;

public class DropboxMedia implements Media {
	
	private static final String apiKey = "4e1dznx9m7r0yvn";
	private static final String apiSecret = "8g4gk64wut4k8eq";
	private static final String accessTokenStr = "Hxv_Q_s3FWAAAAAAAAAAIPtZBpYDO5CFpQAfKpEKswbsdjBdgBfZR8b6hxvV0kPP";
	private static final String DOWNLOAD_FILE_V2_URL = "https://content.dropboxapi.com/2/files/download";
	private static final String DELETE_FILE_V2_URL = "https://api.dropboxapi.com/2/files/delete_v2";
	protected static final String JSON_CONTENT_TYPE = "application/json; charset=utf-8";
	private OAuth20Service service;
	private OAuth2AccessToken accessToken;
	
	
	protected DropboxMedia(OAuth20Service service, OAuth2AccessToken accessToken){
		this.service = service;
		this.accessToken = accessToken;
	}
	
	@Override
	public Result<String> upload(byte[] bytes) {
		// TODO Auto-generated method stub
		try{
			
			OAuthRequest uploadFile = new OAuthRequest(Verb.POST, null);
			uploadFile.addHeader("Dropbox-API-Atg", JSON.encode(new CreateFileV2Args(null)));
			uploadFile.addHeader("Content-Type", "application/octet-stream");
			
			uploadFile.setPayload(bytes);
			
			service.signRequest(accessToken, uploadFile);
			Response r = service.execute(uploadFile);
			
			if(r.getCode() == 409){
				System.err.println("Dropbox file already exists.");
				return Result.error(Result.ErrorCode.CONFLICT);
			}else if(r.getCode() == 200){
				System.err.println("Dropbox file was uploaded with success");
				return Result.ok();
			}else {
				System.err.print("Unexpected error HTTP: " + r.getCode());
				return Result.error(Result.ErrorCode.INTERNAL_ERROR);
			}
		}catch(Exception e){
			e.printStackTrace();
			return Result.error(Result.ErrorCode.INTERNAL_ERROR);
		}
	}

	@Override
	public Result<byte[]> download(String id) {
		// TODO Auto-generated method stub
		try{
			
			OAuthRequest downloadFile = new OAuthRequest(Verb.GET, DOWNLOAD_FILE_V2_URL);
			downloadFile.addHeader("Dropbox-API-Arg", JSON.encode(new AccessFileV2Args(id)));
			
			service.signRequest(accessToken, downloadFile);
			Response r = service.execute(downloadFile);
			
			if(r.getCode() == 200){
				int size = Integer.parseInt(r.getHeader("Content-Length"));
				ByteArrayOutputStream out = new ByteArrayOutputStream(size);
				byte[] buffer = new byte[1024*16];
				int bytesRead;
				while((bytesRead = r.getStream().read(buffer)) != -1)
					out.write(buffer, 0, bytesRead);
				
				System.err.println("Dropbox file was downloaded successfully.");
				return Result.ok(out.toByteArray());
			}else if(r.getCode() == 409) {
				System.err.println("File not found");
				return Result.error(Result.ErrorCode.NOT_FOUND);
			}else{System.err.println("Unexpected error HTTP: " + r.getCode());
			System.err.println(r.getBody());
			return Result.error(Result.ErrorCode.INTERNAL_ERROR);
			}
		}catch(Exception e){
			e.printStackTrace();
			return Result.error(Result.ErrorCode.INTERNAL_ERROR);
		}
	}

	@Override
	public Result<Void> delete(String id) {
		// TODO Auto-generated method stub
		try{
			OAuthRequest deleteFile = new OAuthRequest(Verb.POST, DELETE_FILE_V2_URL);
			deleteFile.addHeader("Content-Type", JSON_CONTENT_TYPE);
			
			deleteFile.setPayload(JSON.encode(new AccessFileV2Args(id)));
			
			service.signRequest(accessToken, deleteFile);
			Response r = service.execute(deleteFile);
			if (r.getCode() == 200) {
				System.err.println("Dropbox file was deleted with success");
				return Result.ok();
			} else if (r.getCode() == 409) {
				System.err.println("File not found");
				return Result.error(Result.ErrorCode.NOT_FOUND);
			} else {
				System.err.println("Unexpected error HTTP: " + r.getCode());
				System.err.println(r.getBody());
				return Result.error(Result.ErrorCode.INTERNAL_ERROR);
			}
		}catch(Exception e){
			e.printStackTrace();
			return Result.error(Result.ErrorCode.INTERNAL_ERROR);
		}
	}

}
