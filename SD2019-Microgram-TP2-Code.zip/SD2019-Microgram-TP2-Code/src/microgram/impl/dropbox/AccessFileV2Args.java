package microgram.impl.dropbox;

public class AccessFileV2Args {
	final String path;
	
	public AccessFileV2Args(String path) {
		this.path = path;
	}
	
}
